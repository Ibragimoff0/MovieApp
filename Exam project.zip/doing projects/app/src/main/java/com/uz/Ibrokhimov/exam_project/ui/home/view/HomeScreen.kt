package com.uz.Ibrokhimov.exam_project.ui.home.view

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import by.kirich1409.viewbindingdelegate.viewBinding
import com.uz.Ibrokhimov.exam_project.R
import com.uz.Ibrokhimov.exam_project.databinding.ScreenHomeBinding
import com.uz.Ibrokhimov.exam_project.ui.home.vm.HomeScreenVM


class HomeScreen : Fragment(R.layout.screen_home) {

    private val binding by viewBinding(ScreenHomeBinding::bind)
    private val homeVM: HomeScreenVM by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        homeVM.getFilmsData()
        observer()

    }

    private fun observer() {

        homeVM.filmsLiveData.observe(requireActivity()) {

            Log.d("TAGaaaa", "observer: ${it.toString()}")

        }

    }


}