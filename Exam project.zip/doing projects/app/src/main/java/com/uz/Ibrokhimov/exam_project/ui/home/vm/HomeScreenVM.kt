package com.uz.Ibrokhimov.exam_project.ui.home.vm

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.uz.Ibrokhimov.exam_project.core.model.popular.FilmsPopularResponse
import com.uz.Ibrokhimov.exam_project.core.repository.FilmsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class HomeScreenVM : ViewModel() {

    private val repository = FilmsRepository()

    val filmsLiveData: MutableLiveData<FilmsPopularResponse?> = MutableLiveData()
    val errorLiveData: MutableLiveData<String?> = MutableLiveData()

    fun getFilmsData() {

        CoroutineScope(Dispatchers.IO).launch {

            val result = repository.getFilms()

            if (result != null) {
                filmsLiveData.value = result.data!!
            } else {
                errorLiveData.value = result.error
            }

        }

    }

}